Put your images in this folder. You can then reference them from index.html using paths such as images/hero.jpg.
